window.primus = {
  name: 'primus',
  version: '0.3.37',
};
